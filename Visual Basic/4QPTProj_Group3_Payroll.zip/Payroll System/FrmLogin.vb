﻿Public Class FrmLogIn
    Public username As String
    Public password As String

    Private Sub FrmLogIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
    End Sub
    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        username = tb_username.Text
        password = tb_password.Text

        'sets different warning for different scenarios
        If (username & password = "") Then

            MessageBox.Show("Please enter valid credentials to proceed.", "Warning")
            Return

        ElseIf (username = "" Or password = "") Then

            MessageBox.Show("One or more credential input is missing.", "Warning")
            Return

        Else

            MessageBox.Show("Logging in the system as: " + username, "Login successful")
            Me.Hide()
            FrmMainWindow.Show()

        End If
    End Sub

    Private Sub btn_loginExit_Click(sender As Object, e As EventArgs) Handles btn_loginExit.Click

        'just a basic confirmation box
        If (MessageBox.Show("Do you want to exit the program?", "Exit?", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes) Then
            Me.Close()
        End If

    End Sub
End Class
