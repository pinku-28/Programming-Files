﻿Public Class FrmMainWindow
    Public username As String
    Public password As String
    Public totalHours As String
    Public overtimeHours As String
    Public payRateNormal As Integer
    Public payRateOvertime As Integer
    Public payRateDay As String
    Public payRateRegular As Integer
    Public payRateOT As Integer
    Public grossPay As Integer
    Public sssFixed As Integer
    Public hdmfRate As Double
    Public phicRate As Double
    Public sssValue As Integer
    Public hdmfValue As Integer
    Public phicValue As Integer
    Public totalDeductions As Integer
    Public basicPayValue As Integer
    Public deMinimisValue As Integer
    Public active As Integer
    Public caseNum As Integer
    Public picture As Integer

    Private Sub FrmMainWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        Dim randomTotalHours As New Random
        Dim randomOverHours As New Random
        Dim imageNum As New Random

        btn_income.FlatStyle = FlatStyle.Standard

        'makes income the active panel and highlights it
        pnl_income.Visible = True
        pnl_earnings.Visible = False
        pnl_deductions.Visible = False
        pnl_about.Visible = False

        btn_income.FlatStyle = FlatStyle.Standard
        btn_earnings.FlatStyle = FlatStyle.Flat
        btn_deductions.FlatStyle = FlatStyle.Flat
        btn_about.FlatStyle = FlatStyle.Flat

        'uses the login credentials as value for the label
        username = FrmLogIn.tb_username.Text
        password = FrmLogIn.tb_password.Text

        lbl_username.Text = username.ToUpper

        'generates a number from 1 to 3
        'which corresponds to a random picture as profile
        picture = imageNum.Next(1, 3)

        Select Case picture
            Case 1
                pb_profile.Image = My.Resources._1
            Case 2
                pb_profile.Image = My.Resources._2
            Case 3
                pb_profile.Image = My.Resources._3
        End Select

        'generates a number from 130 to 160
        'to act as hours of work rendered for the month
        totalHours = randomTotalHours.Next(130, 160)
        lbl_hours.Text = totalHours + " Hours"

        'also generates a number from 0 to 80
        'to act as overtime hours rendered for the month
        overtimeHours = randomOverHours.Next(0, 80)
        lbl_overtime.Text = overtimeHours + " Hours"

        'sets the default pay and overtime pay value per hour of work
        payRateNormal = 73
        payRateOvertime = 80
        payRateDay = payRateNormal * 8

        'uses default pay rates as value for the label
        lbl_payRateNormal.Text = "PHP " + payRateDay
        lbl_payRateOvertime.Text = "PHP " + payRateOvertime.ToString

        'determines 8-hour work hours' and overtime hours' earning values
        payRateRegular = payRateNormal * totalHours
        payRateOT = payRateOvertime * overtimeHours

        'initializes gross pay value
        grossPay = payRateRegular + payRateOT

        'uses the initialized values as label values
        lbl_grossPay.Text = "PHP " + grossPay.ToString

        'initializes the values of each element of deduction
        sssFixed = 675
        hdmfRate = 0.02
        phicRate = 0.04

        'computes the deductions from Gross Pay
        sssValue = sssFixed
        hdmfValue = grossPay * hdmfRate
        phicValue = grossPay * phicRate
        totalDeductions = sssValue + hdmfValue + phicValue

        'displays the corresponding values to the labels assigned
        lbl_sssDeductions.Text = "PHP " + sssValue.ToString
        lbl_hdmfDeductions.Text = "PHP " + hdmfValue.ToString
        lbl_phicDeductions.Text = "PHP " + phicValue.ToString
        lbl_totalDeductions.Text = "PHP " + totalDeductions.ToString
        lbl_deductions.Text = "PHP " + totalDeductions.ToString

        'initializes the basic pay and de minimis amount
        basicPayValue = grossPay - totalDeductions.ToString
        deMinimisValue = 7500

        'displays the basic pay and de minimis on the corresponding labels
        lbl_basicPay.Text = "PHP " + basicPayValue.ToString
        lbl_deMinimis.Text = "PHP " + deMinimisValue.ToString

    End Sub

    Private Sub btn_earnings_Click(sender As Object, e As EventArgs) Handles btn_earnings.Click
        pnl_income.Visible = False
        pnl_earnings.Visible = True
        pnl_deductions.Visible = False
        pnl_about.Visible = False

        btn_income.FlatStyle = FlatStyle.Flat
        btn_earnings.FlatStyle = FlatStyle.Standard
        btn_deductions.FlatStyle = FlatStyle.Flat
        btn_about.FlatStyle = FlatStyle.Flat

    End Sub

    Private Sub btn_deductions_Click(sender As Object, e As EventArgs) Handles btn_deductions.Click
        pnl_income.Visible = False
        pnl_earnings.Visible = False
        pnl_deductions.Visible = True
        pnl_about.Visible = False

        btn_income.FlatStyle = FlatStyle.Flat
        btn_earnings.FlatStyle = FlatStyle.Flat
        btn_deductions.FlatStyle = FlatStyle.Standard
        btn_about.FlatStyle = FlatStyle.Flat

    End Sub

    Private Sub btn_income_Click(sender As Object, e As EventArgs) Handles btn_income.Click
        pnl_income.Visible = True
        pnl_earnings.Visible = False
        pnl_deductions.Visible = False
        pnl_about.Visible = False

        btn_income.FlatStyle = FlatStyle.Standard
        btn_earnings.FlatStyle = FlatStyle.Flat
        btn_deductions.FlatStyle = FlatStyle.Flat
        btn_about.FlatStyle = FlatStyle.Flat

    End Sub

    Private Sub btn_about_Click(sender As Object, e As EventArgs) Handles btn_about.Click
        pnl_income.Visible = False
        pnl_earnings.Visible = False
        pnl_deductions.Visible = False
        pnl_about.Visible = True

        btn_income.FlatStyle = FlatStyle.Flat
        btn_earnings.FlatStyle = FlatStyle.Flat
        btn_deductions.FlatStyle = FlatStyle.Flat
        btn_about.FlatStyle = FlatStyle.Standard

    End Sub

    Private Sub btn_logout_Click(sender As Object, e As EventArgs) Handles btn_logout.Click
        If (MessageBox.Show("Do you want to logout and return to login screen?", "Logout?", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes) Then
            Me.Close()
            FrmLogIn.Show()
        End If
    End Sub
End Class