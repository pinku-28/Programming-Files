﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMainWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMainWindow))
        Me.pnl_buttons = New System.Windows.Forms.Panel()
        Me.pnl_income = New System.Windows.Forms.Panel()
        Me.lbl_deductions = New System.Windows.Forms.Label()
        Me.lbl_deductionDesc = New System.Windows.Forms.Label()
        Me.lbl_grossPay = New System.Windows.Forms.Label()
        Me.lbl_grossDesc = New System.Windows.Forms.Label()
        Me.lbl_payRateOvertime = New System.Windows.Forms.Label()
        Me.lbl_overtimeDesc = New System.Windows.Forms.Label()
        Me.lbl_payRateNormal = New System.Windows.Forms.Label()
        Me.lbl_normalDesc = New System.Windows.Forms.Label()
        Me.lbl_incomeTitle = New System.Windows.Forms.Label()
        Me.pnl_info = New System.Windows.Forms.Panel()
        Me.lbl_overtime = New System.Windows.Forms.Label()
        Me.lbl_hours = New System.Windows.Forms.Label()
        Me.lbl_overtimeTotal = New System.Windows.Forms.Label()
        Me.lbl_hoursTotal = New System.Windows.Forms.Label()
        Me.lbl_position = New System.Windows.Forms.Label()
        Me.lbl_username = New System.Windows.Forms.Label()
        Me.pnl_deductions = New System.Windows.Forms.Panel()
        Me.lbl_totalDeductions = New System.Windows.Forms.Label()
        Me.lbl_totalDeductionsTitle = New System.Windows.Forms.Label()
        Me.lbl_phicDeductions = New System.Windows.Forms.Label()
        Me.lbl_phicTitle = New System.Windows.Forms.Label()
        Me.lbl_hdmfDeductions = New System.Windows.Forms.Label()
        Me.lbl_hdmfTitle = New System.Windows.Forms.Label()
        Me.lbl_sssDeductions = New System.Windows.Forms.Label()
        Me.lbl_sssTitle = New System.Windows.Forms.Label()
        Me.lbl_deductionsTitle = New System.Windows.Forms.Label()
        Me.pnl_earnings = New System.Windows.Forms.Panel()
        Me.lbl_deMinimis = New System.Windows.Forms.Label()
        Me.lbl_deMinimisDesc = New System.Windows.Forms.Label()
        Me.lbl_basicPay = New System.Windows.Forms.Label()
        Me.lbl_basicPayDesc = New System.Windows.Forms.Label()
        Me.lbl_EarningsDesc = New System.Windows.Forms.Label()
        Me.pnl_about = New System.Windows.Forms.Panel()
        Me.lbl_herreraName = New System.Windows.Forms.Label()
        Me.lbl_herreraPosition = New System.Windows.Forms.Label()
        Me.lbl_penasName = New System.Windows.Forms.Label()
        Me.lbl_penasPosition = New System.Windows.Forms.Label()
        Me.pb_herrera = New System.Windows.Forms.PictureBox()
        Me.pb_penas = New System.Windows.Forms.PictureBox()
        Me.pnl_logo = New System.Windows.Forms.Panel()
        Me.pb_profile = New System.Windows.Forms.PictureBox()
        Me.btn_about = New System.Windows.Forms.Button()
        Me.btn_logout = New System.Windows.Forms.Button()
        Me.btn_income = New System.Windows.Forms.Button()
        Me.btn_deductions = New System.Windows.Forms.Button()
        Me.btn_earnings = New System.Windows.Forms.Button()
        Me.pnl_buttons.SuspendLayout()
        Me.pnl_income.SuspendLayout()
        Me.pnl_info.SuspendLayout()
        Me.pnl_deductions.SuspendLayout()
        Me.pnl_earnings.SuspendLayout()
        Me.pnl_about.SuspendLayout()
        CType(Me.pb_herrera, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb_penas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb_profile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnl_buttons
        '
        Me.pnl_buttons.BackColor = System.Drawing.Color.Thistle
        Me.pnl_buttons.Controls.Add(Me.btn_about)
        Me.pnl_buttons.Controls.Add(Me.btn_logout)
        Me.pnl_buttons.Controls.Add(Me.btn_income)
        Me.pnl_buttons.Controls.Add(Me.btn_deductions)
        Me.pnl_buttons.Controls.Add(Me.btn_earnings)
        Me.pnl_buttons.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_buttons.Location = New System.Drawing.Point(-1, 94)
        Me.pnl_buttons.Name = "pnl_buttons"
        Me.pnl_buttons.Size = New System.Drawing.Size(210, 366)
        Me.pnl_buttons.TabIndex = 0
        '
        'pnl_income
        '
        Me.pnl_income.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_income.Controls.Add(Me.lbl_deductions)
        Me.pnl_income.Controls.Add(Me.lbl_deductionDesc)
        Me.pnl_income.Controls.Add(Me.lbl_grossPay)
        Me.pnl_income.Controls.Add(Me.lbl_grossDesc)
        Me.pnl_income.Controls.Add(Me.lbl_payRateOvertime)
        Me.pnl_income.Controls.Add(Me.lbl_overtimeDesc)
        Me.pnl_income.Controls.Add(Me.lbl_payRateNormal)
        Me.pnl_income.Controls.Add(Me.lbl_normalDesc)
        Me.pnl_income.Controls.Add(Me.lbl_incomeTitle)
        Me.pnl_income.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_income.Location = New System.Drawing.Point(209, 151)
        Me.pnl_income.Name = "pnl_income"
        Me.pnl_income.Size = New System.Drawing.Size(361, 306)
        Me.pnl_income.TabIndex = 2
        '
        'lbl_deductions
        '
        Me.lbl_deductions.AutoSize = True
        Me.lbl_deductions.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_deductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_deductions.Location = New System.Drawing.Point(32, 238)
        Me.lbl_deductions.Name = "lbl_deductions"
        Me.lbl_deductions.Size = New System.Drawing.Size(215, 18)
        Me.lbl_deductions.TabIndex = 12
        Me.lbl_deductions.Text = "<insert total deduction amount>"
        '
        'lbl_deductionDesc
        '
        Me.lbl_deductionDesc.AutoSize = True
        Me.lbl_deductionDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_deductionDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_deductionDesc.Location = New System.Drawing.Point(17, 218)
        Me.lbl_deductionDesc.Name = "lbl_deductionDesc"
        Me.lbl_deductionDesc.Size = New System.Drawing.Size(72, 18)
        Me.lbl_deductionDesc.TabIndex = 11
        Me.lbl_deductionDesc.Text = "Deductions"
        '
        'lbl_grossPay
        '
        Me.lbl_grossPay.AutoSize = True
        Me.lbl_grossPay.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_grossPay.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_grossPay.Location = New System.Drawing.Point(32, 186)
        Me.lbl_grossPay.Name = "lbl_grossPay"
        Me.lbl_grossPay.Size = New System.Drawing.Size(128, 18)
        Me.lbl_grossPay.TabIndex = 10
        Me.lbl_grossPay.Text = "<insert gross pay>"
        '
        'lbl_grossDesc
        '
        Me.lbl_grossDesc.AutoSize = True
        Me.lbl_grossDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_grossDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_grossDesc.Location = New System.Drawing.Point(17, 166)
        Me.lbl_grossDesc.Name = "lbl_grossDesc"
        Me.lbl_grossDesc.Size = New System.Drawing.Size(68, 18)
        Me.lbl_grossDesc.TabIndex = 9
        Me.lbl_grossDesc.Text = "Gross Pay"
        '
        'lbl_payRateOvertime
        '
        Me.lbl_payRateOvertime.AutoSize = True
        Me.lbl_payRateOvertime.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_payRateOvertime.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_payRateOvertime.Location = New System.Drawing.Point(32, 134)
        Me.lbl_payRateOvertime.Name = "lbl_payRateOvertime"
        Me.lbl_payRateOvertime.Size = New System.Drawing.Size(117, 18)
        Me.lbl_payRateOvertime.TabIndex = 8
        Me.lbl_payRateOvertime.Text = "<insert pay rate>"
        '
        'lbl_overtimeDesc
        '
        Me.lbl_overtimeDesc.AutoSize = True
        Me.lbl_overtimeDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_overtimeDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_overtimeDesc.Location = New System.Drawing.Point(17, 114)
        Me.lbl_overtimeDesc.Name = "lbl_overtimeDesc"
        Me.lbl_overtimeDesc.Size = New System.Drawing.Size(171, 18)
        Me.lbl_overtimeDesc.TabIndex = 7
        Me.lbl_overtimeDesc.Text = "Per-hour overtime Pay Rate"
        '
        'lbl_payRateNormal
        '
        Me.lbl_payRateNormal.AutoSize = True
        Me.lbl_payRateNormal.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_payRateNormal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_payRateNormal.Location = New System.Drawing.Point(32, 82)
        Me.lbl_payRateNormal.Name = "lbl_payRateNormal"
        Me.lbl_payRateNormal.Size = New System.Drawing.Size(117, 18)
        Me.lbl_payRateNormal.TabIndex = 6
        Me.lbl_payRateNormal.Text = "<insert pay rate>"
        '
        'lbl_normalDesc
        '
        Me.lbl_normalDesc.AutoSize = True
        Me.lbl_normalDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_normalDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_normalDesc.Location = New System.Drawing.Point(17, 64)
        Me.lbl_normalDesc.Name = "lbl_normalDesc"
        Me.lbl_normalDesc.Size = New System.Drawing.Size(140, 18)
        Me.lbl_normalDesc.TabIndex = 4
        Me.lbl_normalDesc.Text = "8-hour work Pay Rate:"
        '
        'lbl_incomeTitle
        '
        Me.lbl_incomeTitle.AutoSize = True
        Me.lbl_incomeTitle.Font = New System.Drawing.Font("Bahnschrift", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_incomeTitle.Location = New System.Drawing.Point(6, 19)
        Me.lbl_incomeTitle.Name = "lbl_incomeTitle"
        Me.lbl_incomeTitle.Size = New System.Drawing.Size(130, 25)
        Me.lbl_incomeTitle.TabIndex = 2
        Me.lbl_incomeTitle.Text = "Total Income"
        '
        'pnl_info
        '
        Me.pnl_info.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_info.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pnl_info.Controls.Add(Me.lbl_overtime)
        Me.pnl_info.Controls.Add(Me.lbl_hours)
        Me.pnl_info.Controls.Add(Me.lbl_overtimeTotal)
        Me.pnl_info.Controls.Add(Me.lbl_hoursTotal)
        Me.pnl_info.Controls.Add(Me.lbl_position)
        Me.pnl_info.Controls.Add(Me.lbl_username)
        Me.pnl_info.Controls.Add(Me.pb_profile)
        Me.pnl_info.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_info.Location = New System.Drawing.Point(209, 0)
        Me.pnl_info.Name = "pnl_info"
        Me.pnl_info.Size = New System.Drawing.Size(361, 148)
        Me.pnl_info.TabIndex = 1
        '
        'lbl_overtime
        '
        Me.lbl_overtime.AutoSize = True
        Me.lbl_overtime.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_overtime.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_overtime.Location = New System.Drawing.Point(17, 123)
        Me.lbl_overtime.Name = "lbl_overtime"
        Me.lbl_overtime.Size = New System.Drawing.Size(165, 18)
        Me.lbl_overtime.TabIndex = 6
        Me.lbl_overtime.Text = "<insert overtime hours>"
        '
        'lbl_hours
        '
        Me.lbl_hours.AutoSize = True
        Me.lbl_hours.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hours.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_hours.Location = New System.Drawing.Point(17, 87)
        Me.lbl_hours.Name = "lbl_hours"
        Me.lbl_hours.Size = New System.Drawing.Size(135, 18)
        Me.lbl_hours.TabIndex = 5
        Me.lbl_hours.Text = "<insert total hours>"
        '
        'lbl_overtimeTotal
        '
        Me.lbl_overtimeTotal.AutoSize = True
        Me.lbl_overtimeTotal.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_overtimeTotal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_overtimeTotal.Location = New System.Drawing.Point(8, 105)
        Me.lbl_overtimeTotal.Name = "lbl_overtimeTotal"
        Me.lbl_overtimeTotal.Size = New System.Drawing.Size(217, 18)
        Me.lbl_overtimeTotal.TabIndex = 4
        Me.lbl_overtimeTotal.Text = "Total recorded overtime this month:"
        '
        'lbl_hoursTotal
        '
        Me.lbl_hoursTotal.AutoSize = True
        Me.lbl_hoursTotal.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hoursTotal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_hoursTotal.Location = New System.Drawing.Point(8, 69)
        Me.lbl_hoursTotal.Name = "lbl_hoursTotal"
        Me.lbl_hoursTotal.Size = New System.Drawing.Size(199, 18)
        Me.lbl_hoursTotal.TabIndex = 3
        Me.lbl_hoursTotal.Text = "Total recorded hours this month:"
        '
        'lbl_position
        '
        Me.lbl_position.AutoSize = True
        Me.lbl_position.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_position.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lbl_position.Location = New System.Drawing.Point(8, 38)
        Me.lbl_position.Name = "lbl_position"
        Me.lbl_position.Size = New System.Drawing.Size(64, 18)
        Me.lbl_position.TabIndex = 2
        Me.lbl_position.Text = "Employee"
        '
        'lbl_username
        '
        Me.lbl_username.AutoSize = True
        Me.lbl_username.Font = New System.Drawing.Font("Bahnschrift", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_username.Location = New System.Drawing.Point(6, 9)
        Me.lbl_username.Name = "lbl_username"
        Me.lbl_username.Size = New System.Drawing.Size(161, 29)
        Me.lbl_username.TabIndex = 1
        Me.lbl_username.Text = "Ipsum, Lorem"
        '
        'pnl_deductions
        '
        Me.pnl_deductions.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_deductions.Controls.Add(Me.lbl_totalDeductions)
        Me.pnl_deductions.Controls.Add(Me.lbl_totalDeductionsTitle)
        Me.pnl_deductions.Controls.Add(Me.lbl_phicDeductions)
        Me.pnl_deductions.Controls.Add(Me.lbl_phicTitle)
        Me.pnl_deductions.Controls.Add(Me.lbl_hdmfDeductions)
        Me.pnl_deductions.Controls.Add(Me.lbl_hdmfTitle)
        Me.pnl_deductions.Controls.Add(Me.lbl_sssDeductions)
        Me.pnl_deductions.Controls.Add(Me.lbl_sssTitle)
        Me.pnl_deductions.Controls.Add(Me.lbl_deductionsTitle)
        Me.pnl_deductions.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_deductions.Location = New System.Drawing.Point(209, 151)
        Me.pnl_deductions.Name = "pnl_deductions"
        Me.pnl_deductions.Size = New System.Drawing.Size(361, 306)
        Me.pnl_deductions.TabIndex = 3
        '
        'lbl_totalDeductions
        '
        Me.lbl_totalDeductions.AutoSize = True
        Me.lbl_totalDeductions.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_totalDeductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_totalDeductions.Location = New System.Drawing.Point(32, 238)
        Me.lbl_totalDeductions.Name = "lbl_totalDeductions"
        Me.lbl_totalDeductions.Size = New System.Drawing.Size(215, 18)
        Me.lbl_totalDeductions.TabIndex = 20
        Me.lbl_totalDeductions.Text = "<insert total deduction amount>"
        '
        'lbl_totalDeductionsTitle
        '
        Me.lbl_totalDeductionsTitle.AutoSize = True
        Me.lbl_totalDeductionsTitle.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_totalDeductionsTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_totalDeductionsTitle.Location = New System.Drawing.Point(17, 218)
        Me.lbl_totalDeductionsTitle.Name = "lbl_totalDeductionsTitle"
        Me.lbl_totalDeductionsTitle.Size = New System.Drawing.Size(103, 18)
        Me.lbl_totalDeductionsTitle.TabIndex = 19
        Me.lbl_totalDeductionsTitle.Text = "Total Deductions"
        '
        'lbl_phicDeductions
        '
        Me.lbl_phicDeductions.AutoSize = True
        Me.lbl_phicDeductions.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_phicDeductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_phicDeductions.Location = New System.Drawing.Point(32, 186)
        Me.lbl_phicDeductions.Name = "lbl_phicDeductions"
        Me.lbl_phicDeductions.Size = New System.Drawing.Size(158, 18)
        Me.lbl_phicDeductions.TabIndex = 18
        Me.lbl_phicDeductions.Text = "<insert phic deduction>"
        '
        'lbl_phicTitle
        '
        Me.lbl_phicTitle.AutoSize = True
        Me.lbl_phicTitle.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_phicTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_phicTitle.Location = New System.Drawing.Point(17, 166)
        Me.lbl_phicTitle.Name = "lbl_phicTitle"
        Me.lbl_phicTitle.Size = New System.Drawing.Size(311, 18)
        Me.lbl_phicTitle.TabIndex = 17
        Me.lbl_phicTitle.Text = "Philippine Health Insurance Corporation (PhilHealth)"
        '
        'lbl_hdmfDeductions
        '
        Me.lbl_hdmfDeductions.AutoSize = True
        Me.lbl_hdmfDeductions.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hdmfDeductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_hdmfDeductions.Location = New System.Drawing.Point(32, 134)
        Me.lbl_hdmfDeductions.Name = "lbl_hdmfDeductions"
        Me.lbl_hdmfDeductions.Size = New System.Drawing.Size(165, 18)
        Me.lbl_hdmfDeductions.TabIndex = 16
        Me.lbl_hdmfDeductions.Text = "<insert hdmf deduction>"
        '
        'lbl_hdmfTitle
        '
        Me.lbl_hdmfTitle.AutoSize = True
        Me.lbl_hdmfTitle.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hdmfTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_hdmfTitle.Location = New System.Drawing.Point(17, 114)
        Me.lbl_hdmfTitle.Name = "lbl_hdmfTitle"
        Me.lbl_hdmfTitle.Size = New System.Drawing.Size(288, 18)
        Me.lbl_hdmfTitle.TabIndex = 15
        Me.lbl_hdmfTitle.Text = "Pag-Ibig Fund (Home Development Mutual Fund)"
        '
        'lbl_sssDeductions
        '
        Me.lbl_sssDeductions.AutoSize = True
        Me.lbl_sssDeductions.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sssDeductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_sssDeductions.Location = New System.Drawing.Point(32, 82)
        Me.lbl_sssDeductions.Name = "lbl_sssDeductions"
        Me.lbl_sssDeductions.Size = New System.Drawing.Size(155, 18)
        Me.lbl_sssDeductions.TabIndex = 14
        Me.lbl_sssDeductions.Text = "<insert sss deduction>"
        '
        'lbl_sssTitle
        '
        Me.lbl_sssTitle.AutoSize = True
        Me.lbl_sssTitle.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sssTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_sssTitle.Location = New System.Drawing.Point(17, 64)
        Me.lbl_sssTitle.Name = "lbl_sssTitle"
        Me.lbl_sssTitle.Size = New System.Drawing.Size(143, 18)
        Me.lbl_sssTitle.TabIndex = 13
        Me.lbl_sssTitle.Text = "Social Security System"
        '
        'lbl_deductionsTitle
        '
        Me.lbl_deductionsTitle.AutoSize = True
        Me.lbl_deductionsTitle.Font = New System.Drawing.Font("Bahnschrift", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_deductionsTitle.Location = New System.Drawing.Point(6, 19)
        Me.lbl_deductionsTitle.Name = "lbl_deductionsTitle"
        Me.lbl_deductionsTitle.Size = New System.Drawing.Size(166, 25)
        Me.lbl_deductionsTitle.TabIndex = 3
        Me.lbl_deductionsTitle.Text = "Total Deductions"
        '
        'pnl_earnings
        '
        Me.pnl_earnings.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_earnings.Controls.Add(Me.lbl_deMinimis)
        Me.pnl_earnings.Controls.Add(Me.lbl_deMinimisDesc)
        Me.pnl_earnings.Controls.Add(Me.lbl_basicPay)
        Me.pnl_earnings.Controls.Add(Me.lbl_basicPayDesc)
        Me.pnl_earnings.Controls.Add(Me.lbl_EarningsDesc)
        Me.pnl_earnings.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_earnings.Location = New System.Drawing.Point(209, 151)
        Me.pnl_earnings.Name = "pnl_earnings"
        Me.pnl_earnings.Size = New System.Drawing.Size(361, 306)
        Me.pnl_earnings.TabIndex = 4
        '
        'lbl_deMinimis
        '
        Me.lbl_deMinimis.AutoSize = True
        Me.lbl_deMinimis.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_deMinimis.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_deMinimis.Location = New System.Drawing.Point(32, 134)
        Me.lbl_deMinimis.Name = "lbl_deMinimis"
        Me.lbl_deMinimis.Size = New System.Drawing.Size(191, 18)
        Me.lbl_deMinimis.TabIndex = 21
        Me.lbl_deMinimis.Text = "<insert de minimis amount>"
        '
        'lbl_deMinimisDesc
        '
        Me.lbl_deMinimisDesc.AutoSize = True
        Me.lbl_deMinimisDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_deMinimisDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_deMinimisDesc.Location = New System.Drawing.Point(17, 114)
        Me.lbl_deMinimisDesc.Name = "lbl_deMinimisDesc"
        Me.lbl_deMinimisDesc.Size = New System.Drawing.Size(71, 18)
        Me.lbl_deMinimisDesc.TabIndex = 20
        Me.lbl_deMinimisDesc.Text = "De Minimis"
        '
        'lbl_basicPay
        '
        Me.lbl_basicPay.AutoSize = True
        Me.lbl_basicPay.Font = New System.Drawing.Font("Bahnschrift", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_basicPay.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_basicPay.Location = New System.Drawing.Point(32, 82)
        Me.lbl_basicPay.Name = "lbl_basicPay"
        Me.lbl_basicPay.Size = New System.Drawing.Size(179, 18)
        Me.lbl_basicPay.TabIndex = 19
        Me.lbl_basicPay.Text = "<insert basic pay amount>"
        '
        'lbl_basicPayDesc
        '
        Me.lbl_basicPayDesc.AutoSize = True
        Me.lbl_basicPayDesc.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_basicPayDesc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_basicPayDesc.Location = New System.Drawing.Point(17, 64)
        Me.lbl_basicPayDesc.Name = "lbl_basicPayDesc"
        Me.lbl_basicPayDesc.Size = New System.Drawing.Size(65, 18)
        Me.lbl_basicPayDesc.TabIndex = 18
        Me.lbl_basicPayDesc.Text = "Basic Pay"
        '
        'lbl_EarningsDesc
        '
        Me.lbl_EarningsDesc.AutoSize = True
        Me.lbl_EarningsDesc.Font = New System.Drawing.Font("Bahnschrift", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_EarningsDesc.Location = New System.Drawing.Point(6, 19)
        Me.lbl_EarningsDesc.Name = "lbl_EarningsDesc"
        Me.lbl_EarningsDesc.Size = New System.Drawing.Size(146, 25)
        Me.lbl_EarningsDesc.TabIndex = 17
        Me.lbl_EarningsDesc.Text = "Total Earnings"
        '
        'pnl_about
        '
        Me.pnl_about.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_about.Controls.Add(Me.lbl_herreraName)
        Me.pnl_about.Controls.Add(Me.lbl_herreraPosition)
        Me.pnl_about.Controls.Add(Me.lbl_penasName)
        Me.pnl_about.Controls.Add(Me.lbl_penasPosition)
        Me.pnl_about.Controls.Add(Me.pb_herrera)
        Me.pnl_about.Controls.Add(Me.pb_penas)
        Me.pnl_about.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_about.Location = New System.Drawing.Point(209, 151)
        Me.pnl_about.Name = "pnl_about"
        Me.pnl_about.Size = New System.Drawing.Size(361, 306)
        Me.pnl_about.TabIndex = 13
        '
        'lbl_herreraName
        '
        Me.lbl_herreraName.AutoSize = True
        Me.lbl_herreraName.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_herreraName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_herreraName.Location = New System.Drawing.Point(187, 166)
        Me.lbl_herreraName.Name = "lbl_herreraName"
        Me.lbl_herreraName.Size = New System.Drawing.Size(136, 18)
        Me.lbl_herreraName.TabIndex = 9
        Me.lbl_herreraName.Text = "Lance Andrei Herrera"
        Me.lbl_herreraName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_herreraPosition
        '
        Me.lbl_herreraPosition.AutoSize = True
        Me.lbl_herreraPosition.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_herreraPosition.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lbl_herreraPosition.Location = New System.Drawing.Point(222, 189)
        Me.lbl_herreraPosition.Name = "lbl_herreraPosition"
        Me.lbl_herreraPosition.Size = New System.Drawing.Size(68, 18)
        Me.lbl_herreraPosition.TabIndex = 8
        Me.lbl_herreraPosition.Text = "Developer"
        Me.lbl_herreraPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_penasName
        '
        Me.lbl_penasName.AutoSize = True
        Me.lbl_penasName.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_penasName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_penasName.Location = New System.Drawing.Point(40, 167)
        Me.lbl_penasName.Name = "lbl_penasName"
        Me.lbl_penasName.Size = New System.Drawing.Size(120, 18)
        Me.lbl_penasName.TabIndex = 7
        Me.lbl_penasName.Text = "John Patrick Peñas"
        Me.lbl_penasName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_penasPosition
        '
        Me.lbl_penasPosition.AutoSize = True
        Me.lbl_penasPosition.Font = New System.Drawing.Font("Bahnschrift Light SemiCondensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_penasPosition.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lbl_penasPosition.Location = New System.Drawing.Point(66, 189)
        Me.lbl_penasPosition.Name = "lbl_penasPosition"
        Me.lbl_penasPosition.Size = New System.Drawing.Size(68, 18)
        Me.lbl_penasPosition.TabIndex = 3
        Me.lbl_penasPosition.Text = "Developer"
        Me.lbl_penasPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pb_herrera
        '
        Me.pb_herrera.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pb_herrera.Image = Global.Payroll_System.My.Resources.Resources._2
        Me.pb_herrera.Location = New System.Drawing.Point(205, 63)
        Me.pb_herrera.Name = "pb_herrera"
        Me.pb_herrera.Size = New System.Drawing.Size(100, 100)
        Me.pb_herrera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb_herrera.TabIndex = 2
        Me.pb_herrera.TabStop = False
        '
        'pb_penas
        '
        Me.pb_penas.Image = Global.Payroll_System.My.Resources.Resources._4
        Me.pb_penas.Location = New System.Drawing.Point(49, 63)
        Me.pb_penas.Name = "pb_penas"
        Me.pb_penas.Size = New System.Drawing.Size(100, 100)
        Me.pb_penas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb_penas.TabIndex = 1
        Me.pb_penas.TabStop = False
        '
        'pnl_logo
        '
        Me.pnl_logo.BackColor = System.Drawing.Color.LavenderBlush
        Me.pnl_logo.BackgroundImage = Global.Payroll_System.My.Resources.Resources.banner
        Me.pnl_logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pnl_logo.Font = New System.Drawing.Font("Bahnschrift", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_logo.Location = New System.Drawing.Point(-1, 0)
        Me.pnl_logo.Name = "pnl_logo"
        Me.pnl_logo.Size = New System.Drawing.Size(210, 94)
        Me.pnl_logo.TabIndex = 3
        '
        'pb_profile
        '
        Me.pb_profile.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pb_profile.Image = Global.Payroll_System.My.Resources.Resources._3
        Me.pb_profile.Location = New System.Drawing.Point(258, 3)
        Me.pb_profile.Name = "pb_profile"
        Me.pb_profile.Size = New System.Drawing.Size(100, 100)
        Me.pb_profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb_profile.TabIndex = 0
        Me.pb_profile.TabStop = False
        '
        'btn_about
        '
        Me.btn_about.FlatAppearance.BorderSize = 0
        Me.btn_about.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_about.Font = New System.Drawing.Font("Bahnschrift", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_about.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_about.Image = Global.Payroll_System.My.Resources.Resources.About_Us
        Me.btn_about.Location = New System.Drawing.Point(107, 284)
        Me.btn_about.Name = "btn_about"
        Me.btn_about.Size = New System.Drawing.Size(103, 82)
        Me.btn_about.TabIndex = 4
        Me.btn_about.Text = "ABOUT US"
        Me.btn_about.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_about.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_about.UseVisualStyleBackColor = True
        '
        'btn_logout
        '
        Me.btn_logout.FlatAppearance.BorderSize = 0
        Me.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_logout.Font = New System.Drawing.Font("Bahnschrift", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_logout.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_logout.Image = Global.Payroll_System.My.Resources.Resources.Logout_1
        Me.btn_logout.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_logout.Location = New System.Drawing.Point(3, 284)
        Me.btn_logout.Name = "btn_logout"
        Me.btn_logout.Size = New System.Drawing.Size(103, 82)
        Me.btn_logout.TabIndex = 3
        Me.btn_logout.Text = "LOGOUT"
        Me.btn_logout.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_logout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_logout.UseVisualStyleBackColor = True
        '
        'btn_income
        '
        Me.btn_income.BackColor = System.Drawing.Color.Thistle
        Me.btn_income.FlatAppearance.BorderSize = 0
        Me.btn_income.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_income.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_income.Image = Global.Payroll_System.My.Resources.Resources.Income
        Me.btn_income.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_income.Location = New System.Drawing.Point(3, 0)
        Me.btn_income.Name = "btn_income"
        Me.btn_income.Size = New System.Drawing.Size(207, 82)
        Me.btn_income.TabIndex = 2
        Me.btn_income.Text = "INCOME"
        Me.btn_income.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_income.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btn_income.UseVisualStyleBackColor = True
        '
        'btn_deductions
        '
        Me.btn_deductions.FlatAppearance.BorderSize = 0
        Me.btn_deductions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_deductions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_deductions.Image = Global.Payroll_System.My.Resources.Resources.Deductions
        Me.btn_deductions.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_deductions.Location = New System.Drawing.Point(3, 88)
        Me.btn_deductions.Name = "btn_deductions"
        Me.btn_deductions.Size = New System.Drawing.Size(207, 82)
        Me.btn_deductions.TabIndex = 1
        Me.btn_deductions.Text = "DEDUCTIONS"
        Me.btn_deductions.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_deductions.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btn_deductions.UseVisualStyleBackColor = True
        '
        'btn_earnings
        '
        Me.btn_earnings.FlatAppearance.BorderSize = 0
        Me.btn_earnings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_earnings.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_earnings.Image = Global.Payroll_System.My.Resources.Resources.Earnings
        Me.btn_earnings.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_earnings.Location = New System.Drawing.Point(3, 173)
        Me.btn_earnings.Name = "btn_earnings"
        Me.btn_earnings.Size = New System.Drawing.Size(207, 82)
        Me.btn_earnings.TabIndex = 0
        Me.btn_earnings.Text = "EARNINGS"
        Me.btn_earnings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_earnings.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btn_earnings.UseVisualStyleBackColor = True
        '
        'FrmMainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LavenderBlush
        Me.ClientSize = New System.Drawing.Size(570, 460)
        Me.Controls.Add(Me.pnl_income)
        Me.Controls.Add(Me.pnl_deductions)
        Me.Controls.Add(Me.pnl_earnings)
        Me.Controls.Add(Me.pnl_about)
        Me.Controls.Add(Me.pnl_logo)
        Me.Controls.Add(Me.pnl_info)
        Me.Controls.Add(Me.pnl_buttons)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FrmMainWindow"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.pnl_buttons.ResumeLayout(False)
        Me.pnl_income.ResumeLayout(False)
        Me.pnl_income.PerformLayout()
        Me.pnl_info.ResumeLayout(False)
        Me.pnl_info.PerformLayout()
        Me.pnl_deductions.ResumeLayout(False)
        Me.pnl_deductions.PerformLayout()
        Me.pnl_earnings.ResumeLayout(False)
        Me.pnl_earnings.PerformLayout()
        Me.pnl_about.ResumeLayout(False)
        Me.pnl_about.PerformLayout()
        CType(Me.pb_herrera, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb_penas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb_profile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnl_buttons As Panel
    Friend WithEvents pnl_info As Panel
    Friend WithEvents pnl_income As Panel
    Friend WithEvents btn_earnings As Button
    Friend WithEvents btn_deductions As Button
    Friend WithEvents pnl_logo As Panel
    Friend WithEvents btn_about As Button
    Friend WithEvents btn_logout As Button
    Friend WithEvents btn_income As Button
    Friend WithEvents pnl_deductions As Panel
    Friend WithEvents pnl_earnings As Panel
    Friend WithEvents lbl_position As Label
    Friend WithEvents lbl_username As Label
    Friend WithEvents pb_profile As PictureBox
    Friend WithEvents lbl_overtime As Label
    Friend WithEvents lbl_hours As Label
    Friend WithEvents lbl_overtimeTotal As Label
    Friend WithEvents lbl_hoursTotal As Label
    Friend WithEvents lbl_normalDesc As Label
    Friend WithEvents lbl_incomeTitle As Label
    Friend WithEvents lbl_payRateOvertime As Label
    Friend WithEvents lbl_overtimeDesc As Label
    Friend WithEvents lbl_payRateNormal As Label
    Friend WithEvents lbl_grossPay As Label
    Friend WithEvents lbl_grossDesc As Label
    Friend WithEvents lbl_deductions As Label
    Friend WithEvents lbl_deductionDesc As Label
    Friend WithEvents lbl_deductionsTitle As Label
    Friend WithEvents lbl_totalDeductions As Label
    Friend WithEvents lbl_totalDeductionsTitle As Label
    Friend WithEvents lbl_phicDeductions As Label
    Friend WithEvents lbl_phicTitle As Label
    Friend WithEvents lbl_hdmfDeductions As Label
    Friend WithEvents lbl_hdmfTitle As Label
    Friend WithEvents lbl_sssDeductions As Label
    Friend WithEvents lbl_sssTitle As Label
    Friend WithEvents lbl_deMinimis As Label
    Friend WithEvents lbl_deMinimisDesc As Label
    Friend WithEvents lbl_basicPay As Label
    Friend WithEvents lbl_basicPayDesc As Label
    Friend WithEvents lbl_EarningsDesc As Label
    Friend WithEvents pnl_about As Panel
    Friend WithEvents pb_herrera As PictureBox
    Friend WithEvents pb_penas As PictureBox
    Friend WithEvents lbl_penasPosition As Label
    Friend WithEvents lbl_herreraName As Label
    Friend WithEvents lbl_herreraPosition As Label
    Friend WithEvents lbl_penasName As Label
End Class
