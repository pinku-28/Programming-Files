﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLogIn
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmLogIn))
        Me.pnl_loginTitle = New System.Windows.Forms.Panel()
        Me.tb_username = New System.Windows.Forms.TextBox()
        Me.tb_password = New System.Windows.Forms.TextBox()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.btn_loginExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'pnl_loginTitle
        '
        Me.pnl_loginTitle.BackgroundImage = Global.Payroll_System.My.Resources.Resources.banner
        Me.pnl_loginTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pnl_loginTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pnl_loginTitle.Location = New System.Drawing.Point(12, 12)
        Me.pnl_loginTitle.Name = "pnl_loginTitle"
        Me.pnl_loginTitle.Size = New System.Drawing.Size(360, 149)
        Me.pnl_loginTitle.TabIndex = 0
        '
        'tb_username
        '
        Me.tb_username.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tb_username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tb_username.Location = New System.Drawing.Point(125, 190)
        Me.tb_username.Name = "tb_username"
        Me.tb_username.Size = New System.Drawing.Size(138, 27)
        Me.tb_username.TabIndex = 2
        Me.tb_username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_password
        '
        Me.tb_password.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tb_password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tb_password.Location = New System.Drawing.Point(125, 242)
        Me.tb_password.Name = "tb_password"
        Me.tb_password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.tb_password.Size = New System.Drawing.Size(138, 27)
        Me.tb_password.TabIndex = 3
        Me.tb_password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.tb_password.UseSystemPasswordChar = True
        '
        'btn_login
        '
        Me.btn_login.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_login.Location = New System.Drawing.Point(155, 275)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(80, 30)
        Me.btn_login.TabIndex = 4
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'btn_loginExit
        '
        Me.btn_loginExit.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btn_loginExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_loginExit.Location = New System.Drawing.Point(155, 311)
        Me.btn_loginExit.Name = "btn_loginExit"
        Me.btn_loginExit.Size = New System.Drawing.Size(80, 30)
        Me.btn_loginExit.TabIndex = 5
        Me.btn_loginExit.Text = "Exit"
        Me.btn_loginExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(148, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 19)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "USERNAME:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(148, 220)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 19)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "PASSWORD:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FrmLogIn
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LavenderBlush
        Me.ClientSize = New System.Drawing.Size(384, 361)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_loginExit)
        Me.Controls.Add(Me.btn_login)
        Me.Controls.Add(Me.tb_password)
        Me.Controls.Add(Me.tb_username)
        Me.Controls.Add(Me.pnl_loginTitle)
        Me.Font = New System.Drawing.Font("Bahnschrift Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "FrmLogIn"
        Me.Text = "BingQilling: Login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnl_loginTitle As Panel
    Friend WithEvents tb_username As TextBox
    Friend WithEvents tb_password As TextBox
    Friend WithEvents btn_login As Button
    Friend WithEvents btn_loginExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
